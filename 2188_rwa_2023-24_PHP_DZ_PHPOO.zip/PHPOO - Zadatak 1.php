<?php

class Osoba {

    public $ime;
    protected $prezime;
    private $godine;

    public function __construct($ime, $prezime, $godine) {
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->godine = $godine;
    }

    public function getIme() {
        return $this->ime;
    }

    protected function getPrezime() {
        return $this->prezime;
    }

    private function getGodine() {
        return $this->godine;
    }

    public function getFullName() {
        return $this->ime . ' ' . $this->prezime;
    }

    public function ispisiInfo() {
        echo "Ime: " . $this->getIme() . "\n";
        echo "Prezime: " . $this->getPrezime() . "\n";
        echo "Godine: " . $this->getGodine() . "\n";
    }
}

$osoba = new Osoba("John", "Doe", 25);

$osoba->ispisiInfo();
?>
