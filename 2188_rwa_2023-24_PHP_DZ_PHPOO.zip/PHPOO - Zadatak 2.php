<?php

class Test {
    public $ime;
    public $prezime;
    public $ostvareni_bodovi;
    public $max_bodovi;
    public $ocjena;

    public function __construct($ime, $prezime, $ostvareni_bodovi, $max_bodovi) {
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->ostvareni_bodovi = $ostvareni_bodovi;
        $this->max_bodovi = $max_bodovi;
        $this->izracunajOcjenu();
    }

    private function izracunajOcjenu() {
        if ($this->max_bodovi > 0) {
            $postotak = ($this->ostvareni_bodovi / $this->max_bodovi) * 100;

            if ($postotak >= 90) {
                $this->ocjena = 'A';
            } elseif ($postotak >= 80) {
                $this->ocjena = 'B';
            } elseif ($postotak >= 70) {
                $this->ocjena = 'C';
            } elseif ($postotak >= 60) {
                $this->ocjena = 'D';
            } else {
                $this->ocjena = 'F';
            }
        } else {
            $this->ocjena = 'Nema ocjene (max_bodovi mora biti veći od 0)';
        }
    }
}

$test1 = new Test("Marko", "Marković", 85, 100);
$test2 = new Test("Ana", "Anić", 60, 80);
$test3 = new Test("Ivan", "Ivanić", 95, 95);

echo "Test 1: Ime: $test1->ime, Prezime: $test1->prezime, Ocjena: $test1->ocjena\n";
echo "Test 2: Ime: $test2->ime, Prezime: $test2->prezime, Ocjena: $test2->ocjena\n";
echo "Test 3: Ime: $test3->ime, Prezime: $test3->prezime, Ocjena: $test3->ocjena\n";

?>
