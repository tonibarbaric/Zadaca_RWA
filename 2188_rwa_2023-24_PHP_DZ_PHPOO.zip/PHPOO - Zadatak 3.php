<?php

class Person {
    public $ime;
    public $prezime;
    public $masa_kg;

    public function __construct($ime, $prezime, $masa_kg) {
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->masa_kg = $masa_kg;
    }

    public function ispisiTezinu() {
        echo "Tezina osobe $this->ime $this->prezime je $this->masa_kg kg.\n";
    }

    public function tezinaNaMjesecu() {
        $tezina_na_mjesecu = $this->masa_kg * 1.625;
        echo "Tezina osobe $this->ime $this->prezime na Mjesecu je $tezina_na_mjesecu kg.\n";
    }
}

$osoba1 = new Person("John", "Doe", 70);
$osoba2 = new Person("Jane", "Doe", 55);
$osoba3 = new Person("Mark", "Smith", 80);

$osoba1->ispisiTezinu();
$osoba2->ispisiTezinu();
$osoba3->ispisiTezinu();

$osoba1->tezinaNaMjesecu();
$osoba2->tezinaNaMjesecu();
$osoba3->tezinaNaMjesecu();

?>
