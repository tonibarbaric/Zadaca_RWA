<?php

class Kalkulator {
   
    private $operand1;
    private $operand2;
    private $rezultat;

    
    public function __construct($operand1, $operand2) {
        $this->operand1 = $operand1;
        $this->operand2 = $operand2;
    }

  
    public function zbroji() {
        $this->rezultat = $this->operand1 + $this->operand2;
    }

    public function oduzmi() {
        $this->rezultat = $this->operand1 - $this->operand2;
    }

  
    public function pomnozi() {
        $this->rezultat = $this->operand1 * $this->operand2;
    }

    
    public function podijeli() {
        if ($this->operand2 != 0) {
            $this->rezultat = $this->operand1 / $this->operand2;
        } else {
            echo "Greška: Nije moguće dijeliti s nulom.\n";
        }
    }

    
    public function ispisiRezultat() {
        echo "Rezultat operacije je: " . $this->rezultat . "\n";
    }
}

$kalkulator1 = new Kalkulator(10, 5);
$kalkulator1->zbroji();
$kalkulator1->ispisiRezultat();

$kalkulator2 = new Kalkulator(8, 2);
$kalkulator2->oduzmi();
$kalkulator2->ispisiRezultat();

$kalkulator3 = new Kalkulator(5, 4);
$kalkulator3->pomnozi();
$kalkulator3->ispisiRezultat();

$kalkulator4 = new Kalkulator(15, 3);
$kalkulator4->podijeli();
$kalkulator4->ispisiRezultat();

$kalkulator5 = new Kalkulator(10, 0);
$kalkulator5->podijeli();

?>
