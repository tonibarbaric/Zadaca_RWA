<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ispis Teksta</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["tekst"], $_GET["broj"])) {
        $uneseniTekst = $_GET["tekst"];
        $uneseniBroj = $_GET["broj"];

        if ($uneseniBroj > 0) {
            echo "<p>Ispis teksta:</p>";
            for ($i = 1; $i <= $uneseniBroj; $i++) {
                echo "$i. $uneseniTekst\n";
            }
        } else {
            echo "<p>Uneseni broj mora biti pozitivan.</p>";
        }
    } else {
        echo "<p>Nisu dostavljeni svi potrebni podaci.</p>";
    }
}
?>

</body>
</html>