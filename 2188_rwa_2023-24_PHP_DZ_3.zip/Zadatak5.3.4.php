<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ispis Obavijesti</title>
</head>
<body>

<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["dugme"])) {
        $odabranoDugme = $_GET["dugme"];

        switch ($odabranoDugme) {
            case 'A':
                echo "<p>Odabrali ste dugme A. Obavijest za dugme A.</p>";
                break;
            case 'B':
                echo "<p>Odabrali ste dugme B. Obavijest za dugme B.</p>";
                break;
            case 'C':
                echo "<p>Odabrali ste dugme C. Obavijest za dugme C.</p>";
                break;
            default:
                echo "<p>Nepoznato dugme.</p>";
                break;
        }
    } else {
        echo "<p>Niste odabrali nijedno dugme.</p>";
    }
}
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get">
    <button type="submit" name="dugme" value="A">Dugme A</button>
    <button type="submit" name="dugme" value="B">Dugme B</button>
    <button type="submit" name="dugme" value="C">Dugme C</button>
</form>

</body>
</html>
