<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator</title>
</head>
<body>

<?php
function Operacija($brojA, $brojB, $operacija) {

    if (isset($brojA, $brojB, $operacija) && is_numeric($brojA) && is_numeric($brojB)) {
        switch ($operacija) {
            case '+':
                return $brojA + $brojB;
            case '-':
                return $brojA - $brojB;
            case '*':
                return $brojA * $brojB;
            case '/':

                if ($brojB != 0) {
                    return $brojA / $brojB;
                } else {
                    return "Nije moguće dijeliti s nulom.";
                }
            default:
                return "Nepoznata operacija.";
        }
    } else {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "GET") {

    if (isset($_GET["brojA"], $_GET["operacija"], $_GET["brojB"])) {
        $rezultat = Operacija($_GET["brojA"], $_GET["brojB"], $_GET["operacija"]);

        if ($rezultat !== false) {
            echo "<p>Rezultat operacije je: $rezultat</p>";
        } else {
            echo "<p>Neispravni podaci. Molimo pokušajte ponovno.</p>";
        }
    }
}
?>

<form method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="brojA">A broj:</label>
    <input type="text" name="brojA" required>
    
    <label for="operacija">Operacija:</label>
    <select name="operacija">
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">x</option>
        <option value="/">/</option>
    </select>
    
    <label for="brojB">B broj:</label>
    <input type="text" name="brojB" required>
    
    <input type="submit" value="Rezultat">
</form>

</body>
</html>
