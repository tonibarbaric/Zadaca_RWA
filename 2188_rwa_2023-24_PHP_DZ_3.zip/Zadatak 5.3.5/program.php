<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET["broj"], $_GET["operacija"], $_GET["salji"])) {
        $broj = $_GET["broj"];
        $operacija = $_GET["operacija"];

        if (empty($broj) || !is_numeric($broj) || empty($operacija)) {
            echo "Molim unesite broj i odaberite operaciju.";
            die();
        }

        switch ($operacija) {
            case 'KVADRAT':
                $rezultat = $broj * $broj;
                echo "Korisnik je unio broj $broj i odabrao kvadrat. Rezultat: $rezultat";
                break;
            case 'KUB':
                $rezultat = $broj * $broj * $broj;
                echo "Korisnik je unio broj $broj i odabrao kub. Rezultat: $rezultat";
                break;
            default:
                echo "Nepoznata operacija.";
                break;
        }
    } else {
        echo "Nisu dostavljeni svi potrebni podaci.";
    }
}
?>