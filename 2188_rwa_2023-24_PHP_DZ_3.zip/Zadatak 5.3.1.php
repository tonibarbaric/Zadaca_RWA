<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Provjera Korisničkih Podataka</title>
</head>
<body>

<?php
function checkpwd($plain_password, $hashed_password) {
    return password_verify($plain_password, $hashed_password);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $korisnickoIme = $_POST["korisnicko_ime"];
    $lozinka = $_POST["lozinka"];

    if ($korisnickoIme == "korisnik" && checkpwd($lozinka, $hashedPasswordFromDatabase)) {
        echo "<p>Korisničko ime je: $korisnickoIme, a lozinka je: $lozinka</p>";
        echo "<p>Podaci su valjani.</p>";
    } else {
        echo "<p>Neispravni podaci. Molimo pokušajte ponovno.</p>";
    }
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <label for="korisnicko_ime">Korisničko Ime:</label>
    <input type="text" name="korisnicko_ime" required>
    <br>

    <label for="lozinka">Lozinka:</label>
    <input type="password" name="lozinka" required>
    <br>

    <input type="submit" value="Pošalji">
</form>

</body>
</html>


