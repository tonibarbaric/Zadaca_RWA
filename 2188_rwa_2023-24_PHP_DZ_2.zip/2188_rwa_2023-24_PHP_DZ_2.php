<?php

// Zadatak 1 - Funkcija ispisuje je li broj prost. Zatim ispisuje sve proste brojeve manje od 100.

echo "Zadatak 1 - Rješenje:\n\n";

function isPrime($number) {
    if ($number <= 1) {
        return false;
    }
    for ($i = 2; $i <= sqrt($number); $i++) {
        if ($number % $i == 0) {
            return false;
        }
    }
    return true;
}

echo "Prosti brojevi manji od 100 su: ";
for ($i = 2; $i < 100; $i++) {
    if (isPrime($i)) {
        echo $i . "\n";
    }
}
echo "\n\n"

// Zadatak 2 - Funkcija ispisuje aritmetičku sredinu dva broja.

echo "Zadatak 2 - Rješenje:\n\n";

function aritmetickaSredina($broj1, $broj2) {
    $sredina = ($broj1 + $broj2) / 2;
    echo "Aritmetička sredina između $broj1 i $broj2 je: $sredina \n";
}

// Pozivi funkcije s proizvoljnim vrednostima
aritmetickaSredina(5, 10);
aritmetickaSredina(20, 30);
aritmetickaSredina(15, 25);
echo "\n\n"

// Zadatak 3 - Funkcija ispisuje aritmetičku i geometrijsku sredinu brojeva.

echo "Zadatak 3 - Rješenje:\n\n";

function sredine($brojeviString) {
    $brojevi = explode(',', $brojeviString);
    $n = count($brojevi);

    $aritmetickaSredina = array_sum($brojevi) / $n;
    echo "Aritmetička sredina brojeva $brojeviString je: $aritmetickaSredina \n";

    $geometrijskaSredina = 1;
    foreach ($brojevi as $broj) {
        $geometrijskaSredina *= $broj;
    }
    $geometrijskaSredina = pow($geometrijskaSredina, 1 / $n);
    echo "Geometrijska sredina brojeva $brojeviString je: $geometrijskaSredina \n";
}

sredine("2,4,6,8");
sredine("1,3,5,7,9");
sredine("10,20,30,40,50");
echo "\n\n"

// Zadatak 4 - PHP kod računa faktorijel za svaki broj do broja koji unesemo kao argument funkcije.

echo "Zadatak 4 - Rješenje:\n\n"

function faktorijel($n) {
    $rezultat = 1;
    for ($i = 1; $i <= $n; $i++) {
        $rezultat *= $i;
    }
    echo "$n = $rezultat\n";
}

faktorijel(5);
faktorijel(7);
faktorijel(10);
echo "\n\n"

// Zadatak 5 - Promjena slova

echo "Zadatak 5 - rješenje: \n\n";

function promjenaSlova($polje, $oblik) {
    if ($oblik == "UPPER") {
        return array_map('strtoupper', $polje);
    } elseif ($oblik == "LOWER") {
        return array_map('strtolower', $polje);
    } else {
        return $polje;
    }
}

$boje = array('B' => 'Blue', 'G' => 'Green', 'r' => 'Red');

echo "Vrijednosti u lowercase: \n";
print_r(promjenaSlova($boje, "LOWER"));

echo "\n" . "Vrijednosti u uppercase: \n";
print_r(promjenaSlova($boje, "UPPER"));
echo "\n\n"

// Zadatak 6 - Funkcija računa i ispisuje prosječnu temperaturu, deset najnižih i deset najviših temperatura.

echo "Zadatak 6 - Rješenje:\n\n";

function prikaziStatistikuTemperatura($temperature) {

    $temperature = explode(",", $temperature);

    $prosjek = array_sum($temperature) / count($temperature);

    sort($temperature);

    $desetNajnizih = array_slice($temperature, 0, 10);

    $desetNajvisih = array_slice($temperature, -10);

    echo "Prosječna temperatura: " . number_format($prosjek, 2) . "°C \n";
    echo "Deset najnižih temperatura: " . implode(", ", $desetNajnizih) . "°C \n";
    echo "Deset najviših temperatura: " . implode(", ", $desetNajvisih) . "°C \n";
}

$temperature = "24, 12, 22, 44, 62, 11, 5, 63, 29, 32, 39, 87, 52, 18, 98, 86";
prikaziStatistikuTemperatura($temperature);