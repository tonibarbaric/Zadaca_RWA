<?php

// Zadatak 1 - Korištenjem for petlje ispisuju se brojevi od 1 do 20 te njihovi kvadrati, svaki u novom redu.

echo "Zadatak 1 – rješenje:\n";

for ($i = 1; $i <= 20; $i++) {

    $kvadrat = $i * $i;

    echo $i . " - " . $kvadrat . "\n";
}
echo "\n";

// Zadatak 2 - Pomoću for petlje računamo sumu prvih 100 prirodnih brojeva.

echo "Zadatak 2 – rješenje:\n";

$suma = 0;

for ($i = 1; $i <= 100; $i++) {

    $suma += $i;
}

echo "Suma prvih 100 prirodnih brojeva je: " . $suma . "\n\n";

// Zadatak 3 - Pomoću while petlje računamo sumu prvih 100 prirodnih brojeva.

echo "Zadatak 3 – rješenje:\n";

$brojac = 1;
$suma = 0;

while ($brojac <= 100) {

    $suma += $brojac;

    $brojac++;
}

echo "Suma prvih 100 prirodnih brojeva je: " . $suma . "\n\n";

// Zadatak 4 - Kod ispisuje sve parne brojeve do 100, svaki u novom redu.

echo "Zadatak 4 – rješenje:\n";

for ($i = 1; $i <= 100; $i++) {

    if ($i % 2 === 0) {

        echo $i . "\n";
    }
}
echo "\n";
// Zadatak 5 - Ispisujemo sve parne troznamenkaste brojeve, svaki u novom redu.

echo "Zadatak 5 – rješenje:\n";

for ($i = 100; $i < 1000; $i++) {

    if ($i % 2 === 0 && $i >= 100 && $i <= 999) {

        echo $i . "\n";
    }
}
echo "\n";
// Zadatak 6 - Ispisujemo sve dvoznamenkaste brojeve djeljive sa 3 i 5 ili s oba.

echo "Zadatak 6 – rješenje:\n";

for ($i = 10; $i < 99; $i++) {

	if ($i % 3 === 0 || $i % 5 === 0 || ($i % 3 === 0 && $i % 5 === 0))

	echo $i . "\n";
}
echo "\n";
/*Zadatak 7 - Zadana je varijabla $grad koja sadržava polje s članovima godina => broj stanovnika. Izračunajte: 
a.	a) Prosječan broj stanovnika kroz sve godine? 
b.	Koje godine je bilo najviše stanovnika? 
c.	Koliko godina se provodilo mjerenje?*/

echo "Zadatak 7 – rješenje:\n";

$grad = array(
    1995 => 24000,
    1997 => 25510,
    1998 => 29154,
    2000 => 32124,
    2002 => 33114
);


$ukupno_stanovnika = array_sum($grad);
$broj_godina = count($grad); // Broj godina
$prosjek_stanovnika = $ukupno_stanovnika / $broj_godina;
echo "a) Prosječan broj stanovnika kroz sve godine: " . $prosjek_stanovnika . "\n";

$max_stanovnika = max($grad); // Maksimalni broj stanovnika
$godine_max_stanovnika = array_keys($grad, $max_stanovnika);
echo "b) Godina s najviše stanovnika: " . implode(", ", $godine_max_stanovnika) . "\n";

$broj_godina_mjerenja = count($grad);
echo "c) Koliko godina se provodilo mjerenje: " . $broj_godina_mjerenja . "\n";
echo "\n";
// Zadatak 8 - Funkcija provjerava je li broj prost i nakon toga ispisujemo sve proste brojeve manje od 100.

echo "Zadatak 8 – rješenje:\n";

function jeliProst($broj) {
    if ($broj <= 1) {
        return false;
    }

    for ($i = 2; $i <= sqrt($broj); $i++) {
        if ($broj % $i === 0) {
            return false;
        }
    }
    return true;
}

echo "Prosti brojevi manji od 100 su:\n";
for ($i = 2; $i < 100; $i++) {
    if (jeliProst($i)) {
        echo $i . "\n";
    }
}
echo "\n";
// Zadatak 9 - Program sve članove polja zbraja pomoću foreach petlje

echo "Zadatak 9 - Rješenje:\n";

$brojevi = array(1, 22, 3, 4, 5, 55, 12, 49, 94, 23, 7);
$zbroj = 0;

foreach ($brojevi as $broj) {
    $zbroj += $broj;
}

echo "Zbroj svih brojeva u polju je: $zbroj" . "\n\n";
// Zadatak 10 - Računamo površinu pravokutnika

echo "Zadatak 10 – rješenje:\n";

$a = 25; // Širina pravokutnika
$b = 40; // Dužina pravokutnika

$povrsina_pravokutnika = $a * $b;

echo "Površina pravokutnika širine $a i dužine $b iznosi $povrsina_pravokutnika";
